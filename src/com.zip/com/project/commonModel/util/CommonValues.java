package com.project.commonModel.util;

import java.util.ArrayList;
import java.util.List;

/**
 *@author wgzx_106
 *@version 创建时间:May 21, 201211:04:10 AM
 */
public class CommonValues {

	/**
	 * 存储过程名称
	 */
	public static String callName = "";
	public static List<String> proceDureParams =new ArrayList<String>();
}
