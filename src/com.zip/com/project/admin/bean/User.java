package com.project.admin.bean;

/**
 * Created by apple on 16/5/21.
 */
public class User {
    String id ;
    String rymc;
    String rynl;
    String jsjb;
    String ssbz;
    String bzmc;
    String password;
    String ryzp;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRymc() {
        return rymc;
    }

    public void setRymc(String rymc) {
        this.rymc = rymc;
    }

    public String getRynl() {
        return rynl;
    }

    public void setRynl(String rynl) {
        this.rynl = rynl;
    }

    public String getJsjb() {
        return jsjb;
    }

    public void setJsjb(String jsjb) {
        this.jsjb = jsjb;
    }

    public String getSsbz() {
        return ssbz;
    }

    public String getBzmc() {
        return bzmc;
    }

    public void setSsbz(String ssbz) {
        this.ssbz = ssbz;
    }

    public void setBzmc(String bzmc) {
        this.bzmc = bzmc;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRyzp() {
        return ryzp;
    }

    public void setRyzp(String ryzp) {
        this.ryzp = ryzp;
    }
}
