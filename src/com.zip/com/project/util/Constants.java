package com.project.util;

/**
 * Created by Founder on 2016/2/25.
 */
public class Constants {
    public static final  String  UPDATE_SUCCESS = "SUCCESS" ;
    public static final  String  UPDATE_ERROR = "ERROR" ;

}
